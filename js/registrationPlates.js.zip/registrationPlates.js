function numberPlates()
{



    


}